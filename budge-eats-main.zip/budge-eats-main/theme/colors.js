export const COLORS = {
  pine: "#237A0F",
  moss: "#82B840",
  teal: "#56B1B4",
  background: "#F3FAEE",
  card: "#FFFFFF",
  text: "#1B3A1A",
  mutedText: "#5F775E",
  border: "#CFE4C9",
  danger: "#BA3939",
};

export const APP_SPACING = {
  screenPadding: 24,
};

