import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useAuth } from "../context/AuthContext";
import { APP_SPACING, COLORS } from "../theme/colors";

export default function LoginScreen({ navigation }) {
  const { signInWithEmail, signInWithGoogle } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const run = async (fn) => {
    try {
      setBusy(true);
      await fn();
    } catch (e) {
      Alert.alert("Auth error", e?.message ?? String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.glowOne} />
      <View style={styles.glowTwo} />

      <View style={styles.card}>
        <Text style={styles.title}>Notesup</Text>
        <Text style={styles.subtitle}>Sign in to continue</Text>

        <Text style={styles.label}>Email</Text>
      <TextInput
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
        placeholder="you@example.com"
        placeholderTextColor={COLORS.mutedText}
        style={styles.input}
      />

        <Text style={styles.label}>Password</Text>
      <TextInput
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        placeholder="password"
        placeholderTextColor={COLORS.mutedText}
        style={styles.input}
      />

      {busy ? (
          <ActivityIndicator color={COLORS.pine} style={styles.loader} />
      ) : (
        <>
            <TouchableOpacity style={styles.primaryButton} onPress={() => run(() => signInWithEmail(email, password))}>
              <Text style={styles.primaryButtonText}>Sign in</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.googleButton} onPress={() => run(() => signInWithGoogle())}>
              <Text style={styles.googleButtonText}>Continue with Google</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.linkRow} onPress={() => navigation.navigate("SignUp")}>
              <Text style={styles.linkText}>Don't have an account? </Text>
              <Text style={[styles.linkText, styles.linkBold]}>Create one</Text>
            </TouchableOpacity>
        </>
      )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    justifyContent: "center",
    padding: APP_SPACING.screenPadding,
    backgroundColor: COLORS.background,
  },
  glowOne: {
    position: "absolute",
    width: 220,
    height: 220,
    borderRadius: 110,
    right: -70,
    top: -30,
    backgroundColor: "rgba(86, 177, 180, 0.22)",
  },
  glowTwo: {
    position: "absolute",
    width: 180,
    height: 180,
    borderRadius: 90,
    left: -50,
    bottom: 50,
    backgroundColor: "rgba(130, 184, 64, 0.2)",
  },
  card: {
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 18,
    padding: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: "800",
    color: COLORS.pine,
    letterSpacing: 0.6,
  },
  subtitle: {
    marginTop: 4,
    marginBottom: 14,
    color: COLORS.mutedText,
  },
  label: {
    marginBottom: 6,
    color: COLORS.text,
    fontWeight: "700",
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 12,
    padding: 11,
    marginBottom: 12,
    color: COLORS.text,
    backgroundColor: "#fff",
  },
  loader: {
    marginVertical: 12,
  },
  primaryButton: {
    backgroundColor: COLORS.pine,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    marginBottom: 10,
  },
  primaryButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
  secondaryButton: {
    backgroundColor: COLORS.moss,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    marginBottom: 10,
  },
  secondaryButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
  googleButton: {
    backgroundColor: COLORS.teal,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
  },
  googleButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
  linkRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 14,
  },
  linkText: {
    color: COLORS.mutedText,
    fontSize: 14,
  },
  linkBold: {
    color: COLORS.pine,
    fontWeight: "700",
  },
});