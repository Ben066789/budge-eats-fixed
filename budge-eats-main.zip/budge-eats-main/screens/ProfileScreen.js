import React, { useEffect, useState } from "react";
import { ActivityIndicator, Image, SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useAuth } from "../context/AuthContext";
import { firebase } from "../firebase";
import { APP_SPACING, COLORS } from "../theme/colors";

export default function ProfileScreen({ navigation }) {
  const { user, signOut } = useAuth();
  const [deckCount, setDeckCount] = useState(0);
  const [cardCount, setCardCount] = useState(0);
  const [loadingCount, setLoadingCount] = useState(true);

  useEffect(() => {
    const ref = firebase.database().ref(`users/${user.uid}/decks`);
    const handler = ref.on("value", (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const decks = Object.values(data);
        setDeckCount(decks.length);
        const total = decks.reduce((sum, deck) => sum + (deck.cards ? Object.keys(deck.cards).length : 0), 0);
        setCardCount(total);
      } else {
        setDeckCount(0);
        setCardCount(0);
      }
      setLoadingCount(false);
    });

    return () => ref.off("value", handler);
  }, [user.uid]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.glowOne} />
      <View style={styles.glowTwo} />

      <View style={styles.headerRow}>
        <Text style={styles.title}>Profile</Text>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Text style={styles.backButtonText}>Back</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.card}>
        <Image source={require("../assets/avatar_icon.png")} style={styles.avatar} />

        <Text style={styles.label}>Email</Text>
        <Text style={styles.value}>{user?.email ?? "No email"}</Text>

        {loadingCount ? (
          <ActivityIndicator color={COLORS.pine} style={styles.loader} />
        ) : (
          <>
            <Text style={styles.label}>Total decks</Text>
            <Text style={styles.value}>{deckCount}</Text>

            <Text style={styles.label}>Total cards</Text>
            <Text style={styles.value}>{cardCount}</Text>
          </>
        )}

        <TouchableOpacity style={styles.signOutButton} onPress={signOut}>
          <Text style={styles.signOutButtonText}>Sign out</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    padding: APP_SPACING.screenPadding,
    backgroundColor: COLORS.background,
  },
  glowOne: {
    position: "absolute",
    width: 200,
    height: 200,
    borderRadius: 100,
    right: -60,
    top: -20,
    backgroundColor: "rgba(86, 177, 180, 0.24)",
  },
  glowTwo: {
    position: "absolute",
    width: 220,
    height: 220,
    borderRadius: 110,
    left: -70,
    bottom: 80,
    backgroundColor: "rgba(130, 184, 64, 0.18)",
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 14,
  },
  title: {
    color: COLORS.pine,
    fontSize: 28,
    fontWeight: "800",
    letterSpacing: 0.5,
  },
  backButton: {
    backgroundColor: COLORS.teal,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
  },
  backButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
  card: {
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 18,
    padding: 16,
    alignItems: "center",
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 14,
    borderWidth: 3,
    borderColor: COLORS.moss,
  },
  label: {
    alignSelf: "flex-start",
    color: COLORS.mutedText,
    fontWeight: "700",
    marginTop: 8,
  },
  value: {
    alignSelf: "flex-start",
    color: COLORS.text,
    fontSize: 18,
    fontWeight: "700",
    marginTop: 4,
    marginBottom: 2,
  },
  loader: {
    marginTop: 10,
    marginBottom: 8,
  },
  signOutButton: {
    marginTop: 16,
    width: "100%",
    backgroundColor: COLORS.pine,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: "center",
  },
  signOutButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
});
