import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Modal,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useAuth } from "../context/AuthContext";
import { firebase } from "../firebase";
import { APP_SPACING, COLORS } from "../theme/colors";

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const [decks, setDecks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [newDeckName, setNewDeckName] = useState("");
  const [confirmVisible, setConfirmVisible] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState(null);

  useEffect(() => {
    const ref = firebase.database().ref(`users/${user.uid}/decks`);
    const handler = ref.on("value", (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const list = Object.entries(data).map(([id, val]) => {
          const cardCount = val.cards ? Object.keys(val.cards).length : 0;
          return { id, name: val.name ?? "Untitled", createdAt: val.createdAt ?? 0, cardCount };
        });
        list.sort((a, b) => b.createdAt - a.createdAt);
        setDecks(list);
      } else {
        setDecks([]);
      }
      setLoading(false);
    });
    return () => ref.off("value", handler);
  }, [user.uid]);

  const createDeck = async () => {
    if (!newDeckName.trim()) {
      Alert.alert("Name required", "Enter a name for your deck.");
      return;
    }
    const now = Date.now();
    try {
      await firebase
        .database()
        .ref(`users/${user.uid}/decks`)
        .push({ name: newDeckName.trim(), createdAt: now, updatedAt: now });
      setNewDeckName("");
      setAdding(false);
    } catch (e) {
      Alert.alert("Error", e?.message ?? String(e));
    }
  };

  const cancelAdding = () => {
    setAdding(false);
    setNewDeckName("");
  };

  const removeDeckById = async (id) => {
    if (!id) return;
    try {
      await firebase.database().ref(`users/${user.uid}/decks/${id}`).remove();
    } catch (e) {
      Alert.alert("Delete failed", e?.message ?? String(e));
    }
  };

  const deleteDeck = (id) => {
    setPendingDeleteId(id);
    setConfirmVisible(true);
  };

  const confirmDelete = () => {
    setConfirmVisible(false);
    void removeDeckById(pendingDeleteId);
    setPendingDeleteId(null);
  };

  const cancelDelete = () => {
    setConfirmVisible(false);
    setPendingDeleteId(null);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.backgroundOrbOne} />
      <View style={styles.backgroundOrbTwo} />

      <View style={styles.headerRow}>
        <View>
          <Text style={styles.appTitle}>flashup</Text>
          <Text style={styles.subtitle}>your flashcard sets</Text>
        </View>
        <TouchableOpacity style={styles.avatarButton} onPress={() => navigation.navigate("Profile")}>
          <Image source={require("../assets/avatar_icon.png")} style={styles.avatarImage} />
        </TouchableOpacity>
      </View>

      {adding ? (
        <View style={styles.composerCard}>
          <TextInput
            placeholder="Deck name..."
            placeholderTextColor={COLORS.mutedText}
            value={newDeckName}
            onChangeText={setNewDeckName}
            style={styles.input}
            autoFocus
          />
          <View style={styles.rowButtons}>
            <TouchableOpacity
              style={[styles.primaryButton, !newDeckName.trim() && styles.disabledButton]}
              onPress={createDeck}
              disabled={!newDeckName.trim()}
            >
              <Text style={styles.primaryButtonText}>Create</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.secondaryButton} onPress={cancelAdding}>
              <Text style={styles.secondaryButtonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <TouchableOpacity style={styles.newDeckButton} onPress={() => setAdding(true)}>
          <Text style={styles.newDeckButtonText}>+ New Deck</Text>
        </TouchableOpacity>
      )}

      {loading ? (
        <ActivityIndicator style={styles.loader} color={COLORS.pine} />
      ) : decks.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyTitle}>No decks yet</Text>
          <Text style={styles.emptyText}>Tap + New Deck to create your first flashcard set.</Text>
        </View>
      ) : (
        <FlatList
          data={decks}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <View style={styles.deckCard}>
              <TouchableOpacity
                onPress={() => navigation.navigate("Deck", { deckId: item.id, deckName: item.name, uid: user.uid })}
                style={styles.deckContent}
              >
                <Text style={styles.deckName}>{item.name}</Text>
                <Text style={styles.deckMeta}>{item.cardCount} {item.cardCount === 1 ? "card" : "cards"}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteChip} onPress={() => deleteDeck(item.id)}>
                <Text style={styles.deleteChipText}>Delete</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}

      <Modal visible={confirmVisible} transparent animationType="fade" onRequestClose={cancelDelete}>
        <Pressable style={styles.modalOverlay} onPress={cancelDelete}>
          <Pressable style={styles.modalCard}>
            <Text style={styles.modalTitle}>Delete this deck?</Text>
            <Text style={styles.modalBody}>All cards in this deck will be lost. This cannot be undone.</Text>
            <View style={styles.modalButtonRow}>
              <TouchableOpacity style={styles.modalCancelButton} onPress={cancelDelete}>
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalDeleteButton} onPress={confirmDelete}>
                <Text style={styles.modalDeleteText}>Delete</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    padding: APP_SPACING.screenPadding,
    backgroundColor: COLORS.background,
  },
  backgroundOrbOne: {
    position: "absolute",
    right: -60,
    top: -40,
    width: 180,
    height: 180,
    borderRadius: 90,
    backgroundColor: "rgba(86, 177, 180, 0.24)",
  },
  backgroundOrbTwo: {
    position: "absolute",
    left: -70,
    bottom: 120,
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: "rgba(130, 184, 64, 0.17)",
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 14,
  },
  appTitle: {
    fontSize: 28,
    color: COLORS.pine,
    fontWeight: "800",
    letterSpacing: 1.2,
  },
  subtitle: {
    color: COLORS.mutedText,
    marginTop: 2,
    fontSize: 12,
  },
  avatarButton: {
    width: 46,
    height: 46,
    borderRadius: 999,
    backgroundColor: "#E3F3DD",
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarImage: {
    width: 30,
    height: 30,
    borderRadius: 15,
  },
  composerCard: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    padding: 12,
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 12,
    padding: 10,
    marginBottom: 10,
    backgroundColor: "#fff",
    color: COLORS.text,
  },
  rowButtons: {
    flexDirection: "row",
    columnGap: 8,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: COLORS.pine,
    borderRadius: 12,
    paddingVertical: 11,
    alignItems: "center",
  },
  primaryButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: COLORS.teal,
    borderRadius: 12,
    paddingVertical: 11,
    alignItems: "center",
  },
  secondaryButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
  disabledButton: {
    opacity: 0.5,
  },
  newDeckButton: {
    marginBottom: 12,
    backgroundColor: COLORS.moss,
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: "center",
  },
  newDeckButtonText: {
    color: "#fff",
    fontWeight: "800",
    letterSpacing: 0.4,
  },
  loader: {
    marginTop: 40,
  },
  listContent: {
    paddingBottom: 8,
  },
  emptyCard: {
    marginTop: 40,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    padding: 20,
    alignItems: "center",
  },
  emptyTitle: {
    color: COLORS.pine,
    fontWeight: "800",
    fontSize: 18,
  },
  emptyText: {
    color: COLORS.mutedText,
    textAlign: "center",
    marginTop: 8,
  },
  deckCard: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: COLORS.card,
  },
  deckContent: {
    flex: 1,
    marginRight: 8,
  },
  deckName: {
    fontWeight: "800",
    fontSize: 16,
    color: COLORS.pine,
  },
  deckMeta: {
    color: COLORS.mutedText,
    fontSize: 12,
    marginTop: 4,
  },
  deleteChip: {
    backgroundColor: "#FFE6E6",
    borderRadius: 999,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: "#F5BABA",
  },
  deleteChipText: {
    color: COLORS.danger,
    fontWeight: "700",
    fontSize: 12,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(10, 40, 10, 0.35)",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  modalCard: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  modalTitle: {
    color: COLORS.pine,
    fontSize: 20,
    fontWeight: "800",
    marginBottom: 6,
  },
  modalBody: {
    color: COLORS.text,
    marginBottom: 14,
  },
  modalButtonRow: {
    flexDirection: "row",
    columnGap: 8,
  },
  modalCancelButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: COLORS.teal,
    borderRadius: 12,
    paddingVertical: 10,
    alignItems: "center",
  },
  modalCancelText: {
    color: COLORS.teal,
    fontWeight: "700",
  },
  modalDeleteButton: {
    flex: 1,
    backgroundColor: COLORS.danger,
    borderRadius: 12,
    paddingVertical: 10,
    alignItems: "center",
  },
  modalDeleteText: {
    color: "#fff",
    fontWeight: "700",
  },
});